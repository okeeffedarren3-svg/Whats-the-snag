SNAGLIST INSTALLABLE WEB APP PACKAGE

Files:
- index.html: app interface and snag management
- manifest.webmanifest: installable app metadata
- service-worker.js: caches the app shell for offline reopening after first load
- README.txt: these instructions

IMPORTANT: This is a package, not a published website. For reliable installation on iPhone, host these files on an HTTPS website. Opening index.html directly from Files or in the ChatGPT preview may not provide persistent storage or PWA installation.

After hosting:
1. Open the HTTPS address in Safari on your iPhone.
2. Tap Share > Add to Home Screen.
3. Launch SnagList from the new Home Screen icon.
4. Add a test snag, close/reopen the app, and confirm it remains.
5. Use Export backup regularly.

Snags and photos are stored in IndexedDB on that device/browser. They do not sync to other devices or a cloud account. Clearing website data or uninstalling may remove local data, so keep backups.
